import SideBar from "@/components/SideBar";

export default function Filtrar_Recomendacoes_Por_Usuario() {
	return (
		<>
			<SideBar active={"recomendacoes_por_usuario"}/>
		</>
	)
}
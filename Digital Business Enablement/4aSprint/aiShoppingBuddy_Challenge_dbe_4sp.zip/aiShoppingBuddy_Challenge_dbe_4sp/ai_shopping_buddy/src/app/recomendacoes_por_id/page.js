import SideBar from "@/components/SideBar";

export default function Filtrar_Recomendacoes_Por_Id() {
	return (
		<>
			<SideBar active={"recomendacoes_por_id"}/>
		</>
	)
}